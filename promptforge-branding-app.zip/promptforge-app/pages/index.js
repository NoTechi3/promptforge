
import { useState } from 'react';

export default function PromptForge() {
  const [form, setForm] = useState({
    businessName: '',
    industry: '',
    style: '',
    colors: '',
    tone: '',
    slogan: '',
    designType: 'logo'
  });
  const [prompt, setPrompt] = useState('');

  const generatePrompt = () => {
    const { businessName, industry, style, colors, tone, slogan, designType } = form;
    const sloganText = slogan ? ` The slogan is: "${slogan}".` : '';
    const output = `Design a ${style}, ${tone} ${designType} for a ${industry} business called "${businessName}". Use colors like ${colors}.${sloganText}`;
    setPrompt(output);
  };

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: '0 auto' }}>
      <h1>PromptForge: Small Biz Branding Prompts</h1>
      <input placeholder="Business Name" value={form.businessName} onChange={e => setForm({ ...form, businessName: e.target.value })} /><br />
      <input placeholder="Industry or Type" value={form.industry} onChange={e => setForm({ ...form, industry: e.target.value })} /><br />
      <input placeholder="Style" value={form.style} onChange={e => setForm({ ...form, style: e.target.value })} /><br />
      <input placeholder="Preferred Colors" value={form.colors} onChange={e => setForm({ ...form, colors: e.target.value })} /><br />
      <input placeholder="Tone" value={form.tone} onChange={e => setForm({ ...form, tone: e.target.value })} /><br />
      <input placeholder="Optional Slogan" value={form.slogan} onChange={e => setForm({ ...form, slogan: e.target.value })} /><br />
      <label>Choose an item to be generated:</label>
      <select value={form.designType} onChange={e => setForm({ ...form, designType: e.target.value })}>
        <option value="logo">Logo</option>
        <option value="business card">Business Card</option>
        <option value="t-shirt">T-Shirt</option>
        <option value="car magnet">Car Magnet</option>
        <option value="coffee mug">Coffee Mug</option>
        <option value="poster">Poster</option>
      </select><br />
      <button onClick={generatePrompt}>Generate Prompt</button>
      {prompt && (
        <div style={{ marginTop: 20 }}>
          <h2>Generated Prompt</h2>
          <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={5} style={{ width: '100%' }} />
          <button onClick={() => navigator.clipboard.writeText(prompt)}>Copy to Clipboard</button>
        </div>
      )}
    </div>
  );
}
